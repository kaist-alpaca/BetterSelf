import 'package:flutter/material.dart';

class homeAdd1 extends StatefulWidget {
  @override
  _homeAdd1 createState() => _homeAdd1();
}

class _homeAdd1 extends State<homeAdd1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('add type 1'),
      ),
    );
  }
}
