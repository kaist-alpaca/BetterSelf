import 'package:flutter/material.dart';

class homeAdd2 extends StatefulWidget {
  @override
  _homeAdd2 createState() => _homeAdd2();
}

class _homeAdd2 extends State<homeAdd2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('add type 2'),
      ),
    );
  }
}
